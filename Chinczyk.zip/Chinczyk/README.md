# Chinczyk
Gra chinczyk na silniku Panda 3D
